package syrux.client.auth;

import syrux.client.ui.MainMenuScreen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.concurrent.CompletionException;

/** In-game authorization for the same account used on the Syrex website. */
public final class SyrexLoginScreen extends Screen {
    private TextFieldWidget email;
    private TextFieldWidget password;
    private ButtonWidget loginButton;
    private boolean loading;
    private String message = "Аккаунт с сайта Syrex — тот же логин и пароль";
    private boolean error;

    public SyrexLoginScreen() { super(Text.literal("Syrex — авторизация")); }

    @Override
    protected void init() {
        super.init();
        int x = width / 2 - 110;
        int y = height / 2 - 66;
        email = new TextFieldWidget(textRenderer, x, y, 220, 20, Text.literal("Email"));
        email.setMaxLength(254);
        email.setPlaceholder(Text.literal("Email аккаунта Syrex"));
        addDrawableChild(email);
        password = new TextFieldWidget(textRenderer, x, y + 28, 220, 20, Text.literal("Пароль"));
        password.setMaxLength(128);
        password.setPlaceholder(Text.literal("Пароль"));
        password.addFormatter((raw, index) -> Text.literal("•".repeat(raw.length())).asOrderedText());
        addDrawableChild(password);

        // Device binding is a requirement for Syrex account login, not a separate
        // checkbox. The notice is always visible before credentials are submitted.
        loginButton = addDrawableChild(ButtonWidget.builder(Text.literal("Войти и привязать этот ПК"), b -> login())
                .dimensions(x, y + 98, 220, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Зарегистрироваться на сайте"), b ->
                net.minecraft.util.Util.getOperatingSystem().open("https://hhhfff0056-crypto.github.io/syrex-client/register"))
                .dimensions(x, y + 126, 220, 20).build());
        setInitialFocus(email);
        updateButton();
    }

    private void updateButton() {
        if (loginButton != null) loginButton.active = !loading;
    }

    private void login() {
        if (loading) return;
        String address = email.getText().trim();
        String secret = password.getText();
        password.setText("");
        if (address.isBlank() || secret.isBlank()) {
            message = "Укажи email и пароль";
            error = true;
            return;
        }
        loading = true;
        error = false;
        message = "Проверяем аккаунт и HWID...";
        updateButton();
        SyrexAuthService.login(address, secret, client.runDirectory.toPath())
                .whenComplete((session, throwable) -> client.execute(() -> {
                    if (client.currentScreen != this) return;
                    loading = false;
                    updateButton();
                    if (throwable != null) {
                        Throwable cause = throwable instanceof CompletionException && throwable.getCause() != null
                                ? throwable.getCause() : throwable;
                        message = cause.getMessage() != null ? cause.getMessage() : "Ошибка подключения к серверу";
                        if (message.length() > 115) message = message.substring(0, 115);
                        error = true;
                    } else {
                        client.setScreen(new MainMenuScreen());
                    }
                }));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, "SYREX CLIENT", width / 2, height / 2 - 98, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "Авторизация прямо в Minecraft", width / 2, height / 2 - 83, 0xFFB1B1B1);
        context.drawCenteredTextWithShadow(textRenderer, "При входе HWID привяжется к аккаунту", width / 2,
                height / 2 - 10, 0xFFD9D9D9);
        context.drawCenteredTextWithShadow(textRenderer, "С другого ПК вход только после сброса", width / 2,
                height / 2 + 2, 0xFFD9D9D9);
        context.drawCenteredTextWithShadow(textRenderer, "Передается только хеш HWID", width / 2,
                height / 2 + 14, 0xFF999999);
        context.drawCenteredTextWithShadow(textRenderer, message, width / 2, height / 2 + 94,
                error ? 0xFFFF7777 : 0xFFC3C3C3);
    }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public void close() { /* Login required before returning to Syrex menus. */ }
}
