package syrux.client.auth;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Uses exactly the same Supabase Auth, UID, Premium key and device binding
 * server as the Syrex website. All privileges are decided by Supabase.
 */
public final class SyrexAuthService {
    private static final String SUPABASE = "https://schhzjmsgdjicoiadoqx.supabase.co";
    // This is a PUBLIC publishable key, safe for a client. Never use service_role here.
    private static final String PUBLISHABLE_KEY = "sb_publishable_ege-vbqEyqsq6HRn7DXtBQ_MQ8Op1UH";
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(8)).build();
    private static final AtomicBoolean CHECKING = new AtomicBoolean(false);
    private static volatile Session session;
    private static volatile long nextCheckAt;

    public record Session(String displayName, long uid, boolean premium, String edition,
                          String expiresAt, String accessToken, String refreshToken,
                          long tokenExpiresAt) { }

    private SyrexAuthService() {}

    public static boolean authenticated() { return session != null; }
    public static boolean premium() { return session != null && session.premium(); }
    public static String displayName() {
        Session current = session;
        return current != null ? current.displayName() : "Player";
    }
    public static Session current() { return session; }
    public static void logout() { session = null; nextCheckAt = 0; }

    public static CompletableFuture<Session> login(String email, String password, Path gameDirectory) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                JsonObject credentials = new JsonObject();
                credentials.addProperty("email", email.trim());
                credentials.addProperty("password", password);
                JsonObject auth = post("/auth/v1/token?grant_type=password", credentials, null);
                String token = required(auth, "access_token");
                String refresh = required(auth, "refresh_token");
                long ttl = number(auth, "expires_in", 3600);
                String username = email.trim().split("@")[0];
                if (auth.has("user") && auth.get("user").isJsonObject()) {
                    JsonObject user = auth.getAsJsonObject("user");
                    JsonObject userMeta = user.has("user_metadata") && user.get("user_metadata").isJsonObject()
                            ? user.getAsJsonObject("user_metadata") : null;
                    if (userMeta != null && userMeta.has("username") && !userMeta.get("username").isJsonNull()) {
                        username = userMeta.get("username").getAsString();
                    }
                }
                if (username.isBlank()) username = "Syrex User";
                if (username.length() > 24) username = username.substring(0, 24);
                String hwid = SyrexDeviceFingerprint.deviceHash(gameDirectory);
                JsonObject binding = bind(token, hwid, "bind");
                Session newSession = makeSession(username, binding, token, refresh,
                        System.currentTimeMillis() + ttl * 1000L);
                session = newSession;
                nextCheckAt = System.currentTimeMillis() + 300_000L;
                return newSession;
            } catch (IOException | InterruptedException e) {
                if (e instanceof InterruptedException) Thread.currentThread().interrupt();
                throw new IllegalStateException(e.getMessage(), e);
            }
        });
    }

    /** Verify license/device every five minutes without blocking the game thread. */
    public static void checkWhenDue(Path gameDirectory) {
        Session existing = session;
        if (existing == null || System.currentTimeMillis() < nextCheckAt || !CHECKING.compareAndSet(false, true)) return;
        nextCheckAt = System.currentTimeMillis() + 300_000L;
        CompletableFuture.runAsync(() -> {
            Session active = session;
            try {
                if (active == null) return;
                String access = active.accessToken();
                String refresh = active.refreshToken();
                long expires = active.tokenExpiresAt();
                if (System.currentTimeMillis() + 60_000L >= expires) {
                    JsonObject input = new JsonObject();
                    input.addProperty("refresh_token", refresh);
                    JsonObject renewed = post("/auth/v1/token?grant_type=refresh_token", input, null);
                    access = required(renewed, "access_token");
                    refresh = required(renewed, "refresh_token");
                    expires = System.currentTimeMillis() + number(renewed, "expires_in", 3600) * 1000L;
                }
                JsonObject state = bind(access, SyrexDeviceFingerprint.deviceHash(gameDirectory), "verify");
                if (session == active) {
                    session = makeSession(active.displayName(), state, access, refresh, expires);
                }
            } catch (Exception error) {
                // Fail closed for Premium. A temporary outage requires renewed login,
                // rather than granting Premium based on a stale local value.
                if (session == active) session = null;
            } finally {
                CHECKING.set(false);
            }
        });
    }

    private static Session makeSession(String username, JsonObject state, String access,
                                       String refresh, long expires) throws IOException {
        if (!state.has("success") || !state.get("success").getAsBoolean())
            throw new IOException("Привязка HWID не подтверждена сервером.");
        return new Session(username, number(state, "uid", 0),
                state.get("premium").getAsBoolean(), required(state, "edition"),
                optional(state, "expiresAt"), access, refresh, expires);
    }

    private static JsonObject bind(String token, String fingerprint, String action)
            throws IOException, InterruptedException {
        JsonObject payload = new JsonObject();
        payload.addProperty("action", action);
        payload.addProperty("hwidHash", fingerprint);
        return post("/functions/v1/syrex-device", payload, token);
    }

    private static JsonObject post(String route, JsonObject body, String token)
            throws IOException, InterruptedException {
        HttpRequest.Builder request = HttpRequest.newBuilder(URI.create(SUPABASE + route))
                .timeout(Duration.ofSeconds(15))
                .header("apikey", PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8));
        if (token != null) request.header("Authorization", "Bearer " + token);
        HttpResponse<String> response = HTTP.send(request.build(),
                HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        JsonObject reply;
        try {
            reply = JsonParser.parseString(response.body()).getAsJsonObject();
        } catch (RuntimeException e) {
            throw new IOException("Сервер Syrex вернул некорректный ответ.", e);
        }
        if (response.statusCode() >= 400) {
            String reason = optional(reply, "error");
            if (reason == null) reason = optional(reply, "msg");
            if (reason == null) reason = optional(reply, "message");
            throw new IOException(reason != null ? reason : "Ошибка авторизации: HTTP " + response.statusCode());
        }
        return reply;
    }

    private static String required(JsonObject value, String name) throws IOException {
        String result = optional(value, name);
        if (result == null) throw new IOException("Нет поля " + name + " в ответе сервера.");
        return result;
    }
    private static String optional(JsonObject value, String name) {
        return value.has(name) && !value.get(name).isJsonNull() ? value.get(name).getAsString() : null;
    }
    private static long number(JsonObject value, String name, long fallback) {
        return value.has(name) && !value.get(name).isJsonNull() ? value.get(name).getAsLong() : fallback;
    }
}
