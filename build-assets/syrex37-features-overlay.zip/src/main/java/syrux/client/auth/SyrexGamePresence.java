package syrux.client.auth;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Pattern;

/**
 * Announce this client's online state to the Syrex website.
 * Account JWT is used to authenticate. The only location data is a public
 * Minecraft server DNS name, which is displayed only after a user opts in
 * at the website. Private servers, IP addresses and singleplayer are hidden.
 */
public final class SyrexGamePresence {
    private static final String URL = "https://schhzjmsgdjicoiadoqx.supabase.co/functions/v1/syrex-game-presence";
    private static final String KEY = "sb_publishable_ege-vbqEyqsq6HRn7DXtBQ_MQ8Op1UH";
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(6)).build();
    private static final Pattern DNS = Pattern.compile("(?i)^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+(?::[0-9]{1,5})?$");
    private static volatile String lastState = "off";
    private static volatile long nextHeartbeat;
    private static volatile String lastAccountToken;

    private SyrexGamePresence() { }

    public static void tick(MinecraftClient mc) {
        SyrexAuthService.Session account = SyrexAuthService.current();
        String token = account == null ? null : account.accessToken();
        boolean playing = token != null && mc.world != null && mc.player != null && !mc.isInSingleplayer();
        ServerInfo server = playing ? mc.getCurrentServerEntry() : null;
        String hostname = server == null ? null : publicHost(server.address);
        String state = playing ? "game:" + (hostname == null ? "" : hostname) : "off";
        long now = System.currentTimeMillis();
        if (!state.equals(lastState) || !java.util.Objects.equals(token, lastAccountToken)) {
            String oldToken = lastAccountToken;
            boolean wasPlaying = lastState.startsWith("game:");
            lastState = state;
            lastAccountToken = token;
            nextHeartbeat = 0;
            if (wasPlaying && ("off".equals(state) || (oldToken != null && !oldToken.equals(token)))) {
                if (oldToken != null) sendAsync(oldToken, "leave", null);
            }
        }
        if (playing && now >= nextHeartbeat) {
            nextHeartbeat = now + 60_000L;
            sendAsync(token, "heartbeat", hostname);
        }
    }

    private static String publicHost(String value) {
        if (value == null || value.length() > 125) return null;
        String host = value.trim().toLowerCase(java.util.Locale.ROOT);
        if (!DNS.matcher(host).matches()) return null;
        String name = host.replaceFirst(":\\d{1,5}$", "");
        String tld = name.substring(name.lastIndexOf('.') + 1);
        if (!tld.matches("[a-z]{2,24}") || name.endsWith(".local") || name.endsWith(".lan")
                || name.endsWith(".home") || name.endsWith(".localhost")
                || name.endsWith(".internal") || name.endsWith(".test") || name.endsWith(".invalid")) return null;
        if (host.contains(":")) {
            int port = Integer.parseInt(host.substring(host.lastIndexOf(':') + 1));
            if (port < 1 || port > 65535) return null;
        }
        return host;
    }

    private static void sendAsync(String token, String action, String host) {
        CompletableFuture.runAsync(() -> {
            try {
                String body = "{\"action\":\"" + action + "\",\"server\":"
                    + (host == null ? "null" : "\"" + host + "\"") + "}";
                HttpRequest req = HttpRequest.newBuilder(URI.create(URL))
                        .header("apikey", KEY)
                        .header("Authorization", "Bearer " + token)
                        .header("Content-Type", "application/json")
                        .timeout(Duration.ofSeconds(12))
                        .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                        .build();
                HTTP.send(req, HttpResponse.BodyHandlers.discarding());
            } catch (Exception ignored) {
                // Network status is best-effort and must not block gameplay.
            }
        });
    }
}
