package syrux.client.auth;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * Computes a local device fingerprint for a required, clearly disclosed account binding.
 * No serial numbers, raw MachineGuid, or machine-id are transmitted.
 */
public final class SyrexDeviceFingerprint {
    private SyrexDeviceFingerprint() {}

    public static String deviceHash(Path gameDirectory) throws IOException {
        String id = operatingSystemMachineId();
        if (id == null || id.isBlank()) {
            // On unsupported OSes, use a stable per-installation identifier instead.
            id = installationId(gameDirectory);
        }
        return sha256("syrex-hwid-v1:" + id);
    }

    private static String operatingSystemMachineId() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (os.contains("win")) {
            try {
                Process process = new ProcessBuilder("reg", "query",
                        "HKLM\\SOFTWARE\\Microsoft\\Cryptography", "/v", "MachineGuid")
                        .redirectErrorStream(true).start();
                if (!process.waitFor(3, TimeUnit.SECONDS)) {
                    process.destroyForcibly();
                    return null;
                }
                if (process.exitValue() != 0) return null;
                String output = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
                for (String line : output.split("\\R")) {
                    if (line.toLowerCase(Locale.ROOT).contains("machineguid")) {
                        String[] match = line.trim().split("\\s+REG_SZ\\s+", 2);
                        if (match.length == 2 && !match[1].isBlank()) return "windows:" + match[1].trim();
                    }
                }
            } catch (IOException | InterruptedException | SecurityException e) {
                if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            }
        } else if (os.contains("linux")) {
            for (String location : new String[]{"/etc/machine-id", "/var/lib/dbus/machine-id"}) {
                try {
                    String id = Files.readString(Path.of(location), StandardCharsets.UTF_8).trim();
                    if (!id.isBlank()) return "linux:" + id;
                } catch (IOException | SecurityException ignored) {
                    // Fall through to installation identity.
                }
            }
        }
        return null;
    }

    private static String installationId(Path gameDirectory) throws IOException {
        Path file = gameDirectory.resolve("config").resolve("syrex").resolve("device-id.txt");
        Files.createDirectories(file.getParent());
        if (Files.exists(file)) {
            String existing = Files.readString(file, StandardCharsets.UTF_8).trim();
            if (!existing.isBlank() && existing.length() <= 80) return "install:" + existing;
        }
        String generated = UUID.randomUUID().toString();
        try {
            Files.writeString(file, generated + "\n", StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
        } catch (java.nio.file.FileAlreadyExistsException race) {
            return "install:" + Files.readString(file, StandardCharsets.UTF_8).trim();
        }
        return "install:" + generated;
    }

    private static String sha256(String text) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                    .digest(text.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Java requires SHA-256", e);
        }
    }
}
