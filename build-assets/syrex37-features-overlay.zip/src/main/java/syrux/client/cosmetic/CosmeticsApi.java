package syrux.client.cosmetic;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.session.Session;
import syrux.client.SyruxClient;
import syrux.client.auth.SyrexAuthService;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Cosmetics are saved in the same Syrex Supabase account as the HWID and license.
 * Other Syrex clients load a player's publicly equipped cosmetic IDs by Minecraft UUID.
 * Only local catalogue IDs are rendered: remote data never contains model URLs or code.
 */
public final class CosmeticsApi {
    private static final String ENDPOINT = "https://schhzjmsgdjicoiadoqx.supabase.co/functions/v1/syrex-cosmetics";
    // A publishable (non-secret) key; Supabase Auth protects every write.
    private static final String PUBLIC_KEY = "sb_publishable_ege-vbqEyqsq6HRn7DXtBQ_MQ8Op1UH";
    private static final long CACHE_MS = 45_000L;
    private static final HttpClient HTTP = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(8)).build();
    private static final ScheduledExecutorService SCHEDULER = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread thread = new Thread(r, "syrex-cosmetics-sync");
        thread.setDaemon(true);
        return thread;
    });
    private static final CosmeticsApi INSTANCE = new CosmeticsApi();

    private record Cached(JsonObject equipped, long until) { }
    private final Map<UUID, Cached> cache = new ConcurrentHashMap<>();
    private final Map<UUID, CompletableFuture<JsonObject>> requests = new ConcurrentHashMap<>();
    private final AtomicLong localChangeVersion = new AtomicLong();
    private volatile long lastAccountUid = -1;
    private volatile long nextMineFetch = 0L;
    private volatile long lastLinkAttempt = 0L;
    private volatile UUID linkedWorldUuid;
    private volatile boolean applyingCloud;
    private volatile ScheduledFuture<?> pendingSave;
    private volatile long nextBatchAt;
    private volatile Object lastWorld;

    private CosmeticsApi() {}
    public static CosmeticsApi getInstance() { return INSTANCE; }

    /** Called every client tick, without blocking Minecraft's game thread. */
    public void tick(MinecraftClient mc) {
        SyrexAuthService.Session session = SyrexAuthService.current();
        if (session == null) {
            lastAccountUid = -1L;
            linkedWorldUuid = null;
            nextMineFetch = 0;
            cache.clear();
            return;
        }
        long now = System.currentTimeMillis();
        if (session.uid() != lastAccountUid) {
            lastAccountUid = session.uid();
            localChangeVersion.incrementAndGet();
            synchronized (this) {
                if (pendingSave != null) pendingSave.cancel(false);
                pendingSave = null;
            }
            linkedWorldUuid = null;
            nextMineFetch = 0;
            cache.clear();
        }
        if (now >= nextMineFetch) {
            nextMineFetch = now + 35_000L;
            loadMine(session);
        }
        if (lastWorld != mc.world) {
            lastWorld = mc.world;
            cache.clear();
            nextBatchAt = 0L;
        }
        if (mc.player != null) {
            if (mc.world != null && now >= nextBatchAt) {
                nextBatchAt = now + 15_000L;
                prefetchVisible(mc);
            }
            UUID uuid = mc.player.getUuid();
            Session officialSession = mc.getSession();
            if (uuid != null && officialSession != null && uuid.equals(officialSession.getUuidOrNull())
                    && !officialSession.getAccessToken().isBlank() && !uuid.equals(linkedWorldUuid)
                    && now - lastLinkAttempt >= 30_000L) {
                lastLinkAttempt = now;
                link(session, uuid).thenAccept(reply -> linkedWorldUuid = uuid)
                    .exceptionally(error -> { warn("Minecraft UUID binding failed", error); return null; });
            }
        } else {
            linkedWorldUuid = null;
        }
    }

    /** Load latest website selections and apply them on Minecraft's render thread. */
    private CompletableFuture<Void> loadMine(SyrexAuthService.Session active) {
        long changesAtRequest = localChangeVersion.get();
        return request("mine", null, active.accessToken()).thenAccept(reply -> {
            if (SyrexAuthService.current() == null || SyrexAuthService.current().uid() != active.uid()) return;
            if (reply.has("linked") && reply.get("linked").getAsBoolean()
                    && reply.has("playerUuid") && !reply.get("playerUuid").isJsonNull()) {
                try { linkedWorldUuid = UUID.fromString(reply.get("playerUuid").getAsString()); }
                catch (IllegalArgumentException ignored) { }
            }
            if (reply.has("saved") && reply.get("saved").getAsBoolean()
                    && reply.has("equipped") && reply.get("equipped").isJsonObject()) {
                JsonObject equipped = reply.getAsJsonObject("equipped");
                MinecraftClient mc = MinecraftClient.getInstance();
                mc.execute(() -> {
                    if (localChangeVersion.get() != changesAtRequest) return;
                    applyingCloud = true;
                    try { CosmeticStore.applySyncedLoadout(equipped); }
                    finally { applyingCloud = false; }
                });
            } else if (changesAtRequest == localChangeVersion.get()) {
                MinecraftClient.getInstance().execute(() -> {
                    if (changesAtRequest == localChangeVersion.get()) {
                        onLocalSelectionChanged(); // Initial local selections for this account.
                    }
                });
            }
        }).whenComplete((ignored, error) -> {
            if (error != null) warn("Could not read account cosmetics", error);
        });
    }

    public CompletableFuture<Void> forceAccountRefresh() {
        SyrexAuthService.Session current = SyrexAuthService.current();
        return current == null ? CompletableFuture.failedFuture(new IllegalStateException("Войдите в аккаунт Syrex."))
            : loadMine(current);
    }

    /**
     * Link an actual Minecraft Java account using Mojang sessionserver proof.
     * The Minecraft access token is sent ONLY to Mojang via HTTPS; Syrex gets
     * a one-time server challenge + Minecraft username, not Microsoft tokens.
     */
    private CompletableFuture<JsonObject> link(SyrexAuthService.Session active, UUID playerUuid) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Session minecraftSession = mc.getSession();
        if (minecraftSession == null || minecraftSession.getUuidOrNull() == null
                || !playerUuid.equals(minecraftSession.getUuidOrNull())
                || minecraftSession.getAccessToken() == null
                || minecraftSession.getAccessToken().isBlank()) {
            // Offline/unauthenticated sessions cannot claim an online UUID.
            return CompletableFuture.failedFuture(new IllegalStateException(
                "Minecraft online session required to link cosmetics"));
        }
        String token = minecraftSession.getAccessToken();
        String username = minecraftSession.getUsername();
        JsonObject empty = new JsonObject();
        return request("challenge", empty, active.accessToken()).thenCompose(challenge -> {
            String serverId = challenge.get("serverId").getAsString();
            JsonObject joinBody = new JsonObject();
            joinBody.addProperty("accessToken", token);
            joinBody.addProperty("selectedProfile", playerUuid.toString().replace("-", ""));
            joinBody.addProperty("serverId", serverId);
            HttpRequest joinRequest = HttpRequest.newBuilder(
                    URI.create("https://sessionserver.mojang.com/session/minecraft/join"))
                .timeout(Duration.ofSeconds(12))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(joinBody.toString(), StandardCharsets.UTF_8))
                .build();
            return HTTP.sendAsync(joinRequest, HttpResponse.BodyHandlers.discarding())
                .thenCompose(joinReply -> {
                    if (joinReply.statusCode() != 204) {
                        return CompletableFuture.failedFuture(new IllegalStateException(
                            "Minecraft Java account could not be verified"));
                    }
                    JsonObject linkBody = new JsonObject();
                    linkBody.addProperty("playerUuid", playerUuid.toString());
                    linkBody.addProperty("username", username);
                    linkBody.addProperty("serverId", serverId);
                    return request("link", linkBody, active.accessToken());
                });
        });
    }

    /** Asynchronous account save, debounced so rapid GUI clicks do not race each other. */
    public synchronized void onLocalSelectionChanged() {
        if (applyingCloud || SyrexAuthService.current() == null) return;
        localChangeVersion.incrementAndGet();
        JsonObject snapshot = CosmeticStore.exportLoadout();
        if (pendingSave != null) pendingSave.cancel(false);
        pendingSave = SCHEDULER.schedule(() -> {
            SyrexAuthService.Session active = SyrexAuthService.current();
            if (active == null) return;
            JsonObject input = new JsonObject();
            input.add("equipped", snapshot);
            request("save", input, active.accessToken())
                .exceptionally(error -> { warn("Could not save cosmetics", error); return null; });
        }, 650L, TimeUnit.MILLISECONDS);
    }

    /** Render-thread read only; all networking runs in batched async tick calls. */
    public JsonObject get(UUID uuid) {
        if (uuid == null) return null;
        Cached hit = cache.get(uuid);
        return hit != null && System.currentTimeMillis() < hit.until() ? hit.equipped() : null;
    }

    /** One lookup for up to 30 visible players, not one HTTP request per frame/player. */
    private void prefetchVisible(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        java.util.List<UUID> pending = new java.util.ArrayList<>();
        for (AbstractClientPlayerEntity player : mc.world.getPlayers()) {
            UUID uuid = player.getUuid();
            if (mc.player != null && uuid.equals(mc.player.getUuid())) continue;
            Cached item = cache.get(uuid);
            if (item == null || item.until() <= now) pending.add(uuid);
        }
        for (int start = 0; start < pending.size(); start += 30) {
            java.util.List<UUID> batch = new java.util.ArrayList<>(
                pending.subList(start, Math.min(start + 30, pending.size())));
            for (UUID id : batch) cache.put(id, new Cached(new JsonObject(), now + 10_000L));
            JsonObject args = new JsonObject();
            JsonArray uuids = new JsonArray();
            for (UUID id : batch) uuids.add(id.toString());
            args.add("uuids", uuids);
            SyrexAuthService.Session active = SyrexAuthService.current();
            if (active == null) continue;
            request("lookup", args, active.accessToken()).thenAccept(reply -> {
                Map<UUID, JsonObject> found = new java.util.HashMap<>();
                JsonArray profiles = reply.has("profiles") && reply.get("profiles").isJsonArray()
                    ? reply.getAsJsonArray("profiles") : new JsonArray();
                for (JsonElement part : profiles) {
                    if (!part.isJsonObject()) continue;
                    JsonObject record = part.getAsJsonObject();
                    if (!record.has("uuid") || !record.has("equipped") || !record.get("equipped").isJsonObject()) continue;
                    try { found.put(UUID.fromString(record.get("uuid").getAsString()),
                        record.getAsJsonObject("equipped")); }
                    catch (IllegalArgumentException ignored) { }
                }
                long expiry = System.currentTimeMillis() + CACHE_MS;
                for (UUID id : batch) cache.put(id,
                    new Cached(found.getOrDefault(id, new JsonObject()), expiry));
            }).exceptionally(error -> { warn("Could not read nearby cosmetics", error); return null; });
        }
    }

    private CompletableFuture<JsonObject> fetchAsync(UUID uuid) {
        JsonObject args = new JsonObject();
        JsonArray uuids = new JsonArray();
        uuids.add(uuid.toString());
        args.add("uuids", uuids);
        SyrexAuthService.Session active = SyrexAuthService.current();
        if (active == null) return CompletableFuture.completedFuture(new JsonObject());
        return request("lookup", args, active.accessToken()).thenApply(reply -> {
            JsonArray profiles = reply.has("profiles") && reply.get("profiles").isJsonArray()
                ? reply.getAsJsonArray("profiles") : new JsonArray();
            if (!profiles.isEmpty()) {
                JsonObject profile = profiles.get(0).getAsJsonObject();
                if (profile.has("equipped") && profile.get("equipped").isJsonObject()) {
                    return profile.getAsJsonObject("equipped");
                }
            }
            return new JsonObject();
        });
    }

    public CosmeticEntry getEquipped(UUID uuid, CosmeticCategory category) {
        JsonObject data = get(uuid);
        if (data == null) return null;
        String name = category.name().toLowerCase(java.util.Locale.ROOT);
        if (!data.has(name) || !data.get(name).isJsonPrimitive()) return null;
        try {
            int id = data.get(name).getAsInt();
            CosmeticEntry entry = CosmeticCatalog.method0518(id);
            return entry != null && entry.category() == category ? entry : null;
        } catch (Exception ignored) { return null; }
    }

    /** Compatibility for old cape menus; the full local loadout is authoritative. */
    public CompletableFuture<Void> save(UUID uuid, JsonObject data) {
        onLocalSelectionChanged();
        return CompletableFuture.completedFuture(null);
    }
    public void setCape(UUID uuid, String capeId) { onLocalSelectionChanged(); }
    public void clearCape(UUID uuid) { onLocalSelectionChanged(); }
    public String getCapeId(UUID uuid) {
        JsonObject selected = get(uuid);
        return selected != null && selected.has("cape") ? selected.get("cape").getAsString() : null;
    }
    public CompletableFuture<JsonObject> forceRefresh(UUID uuid) {
        cache.remove(uuid);
        return fetchAsync(uuid).thenApply(data -> {
            cache.put(uuid, new Cached(data, System.currentTimeMillis() + CACHE_MS));
            return data;
        });
    }

    private CompletableFuture<JsonObject> request(String action, JsonObject args, String jwt) {
        JsonObject body = args == null ? new JsonObject() : args.deepCopy();
        body.addProperty("action", action);
        HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(ENDPOINT))
            .timeout(Duration.ofSeconds(12))
            .header("Content-Type", "application/json")
            .header("apikey", PUBLIC_KEY)
            .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8));
        if (jwt != null) builder.header("Authorization", "Bearer " + jwt);
        return HTTP.sendAsync(builder.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8))
            .thenApply(result -> {
                try {
                    JsonObject json = JsonParser.parseString(result.body()).getAsJsonObject();
                    if (result.statusCode() >= 400) {
                        String reason = json.has("error") ? json.get("error").getAsString() : "HTTP " + result.statusCode();
                        throw new IllegalStateException(reason);
                    }
                    return json;
                } catch (RuntimeException ex) {
                    throw new IllegalStateException("Syrex cosmetics: invalid response", ex);
                }
            });
    }
    private static void warn(String message, Throwable error) {
        SyruxClient.logger().warn("[Syrex Cosmetics] {}: {}", message, error.getMessage());
    }
}
