package syrux.client.cosmetic;

import syrux.client.auth.SyrexAuthService;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Compatibility adapter. Syrex Supabase replaced the obsolete Render API. */
public final class CosmeticSync {
    private static final CosmeticSync INSTANCE = new CosmeticSync();
    private CosmeticSync() { }
    public static CosmeticSync getInstance() { return INSTANCE; }
    public void initialize() { }
    public CompletableFuture<Void> syncFromServer() { return CosmeticsApi.getInstance().forceAccountRefresh(); }
    public CompletableFuture<Void> forceSync() { return syncFromServer(); }
    public CompletableFuture<Void> pushEquippedCosmetics() {
        CosmeticsApi.getInstance().onLocalSelectionChanged();
        return CompletableFuture.completedFuture(null);
    }
    // Cosmetic entitlement validation is not yet part of the account service.
    // Preserve the original client default: all catalogue cosmetics are locally selectable.
    public boolean isSynced() { return SyrexAuthService.authenticated(); }
    public boolean isOwned(CosmeticEntry entry) { return entry != null; }
    public boolean isOwned(int cosmeticId) { return CosmeticCatalog.method0518(cosmeticId) != null; }
    public CosmeticEntry getEquipped(CosmeticCategory category) { return CosmeticStore.method3519(category); }
    public void setEquipped(CosmeticCategory category, CosmeticEntry cosmetic) {
        if (cosmetic == null) CosmeticStore.method3517(category);
        else CosmeticStore.method3513(cosmetic);
    }
    public void markOwned(CosmeticEntry cosmetic) { }
    public List<Integer> getOwnedCosmeticIds() {
        List<Integer> ids = new ArrayList<>();
        for (CosmeticEntry entry : CosmeticCatalog.method0524()) ids.add(entry.id());
        return ids;
    }
    /** Deprecated: no external API keys are needed or accepted. */
    public void updateConfig(String apiBase, String apiKey) { }
}
