package syrux.client.module;

import syrux.client.module.misc.AdminRecordModule;
import syrux.client.module.misc.AdminShardModule;
import syrux.client.module.misc.BaseFinderModule;
import syrux.client.module.combat.AimAssistModule;
import syrux.client.module.movement.AirStuckModule;
import syrux.client.module.render.ArmorBarModule;
import syrux.client.module.render.ArrowsModule;
import syrux.client.module.render.AspectRatioModule;
import syrux.client.module.combat.AttackAuraModule;
import syrux.client.module.misc.AuctionHelperModule;
import syrux.client.module.misc.AutoAcceptModule;
import syrux.client.module.misc.AutoAppleFarmModule;
import syrux.client.module.misc.AutoBuyModule;
import syrux.client.module.misc.AutoDeliverModule;
import syrux.client.module.misc.AutoEatModule;
import syrux.client.module.player.AutoExpModule;
import syrux.client.module.misc.AutoLeaveModule;
import syrux.client.module.misc.AutoMessageModule;
import syrux.client.module.misc.AutoMineModule;
import syrux.client.module.misc.AutoRegisterModule;
import syrux.client.module.misc.AutoSellModule;
import syrux.client.module.movement.AutoSprintModule;
import syrux.client.module.combat.AutoSwapModule;
import syrux.client.module.misc.AutoToolModule;
import syrux.client.module.combat.AutoTotemModule;
import syrux.client.module.misc.AutoVillagerModule;
import syrux.client.module.misc.AutoWardenModule;
import syrux.client.module.combat.BackTrackModule;
import syrux.client.module.misc.BassBoostModule;
import syrux.client.module.misc.BotManagerModule;
import syrux.client.module.render.BlockEspModule;
import syrux.client.module.render.BlockOverlayModule;
import syrux.client.module.combat.BlockSlotModule;
import syrux.client.module.render.BrightnessModule;
import syrux.client.module.render.CameraFeatureModule;
import syrux.client.module.render.ChamsModule;
import syrux.client.module.misc.ChestStealerModule;
import syrux.client.module.misc.ClanUpgraderModule;
import syrux.client.module.player.ClickActionModule;
import syrux.client.module.render.CrosshairModule;
import syrux.client.module.render.CustomWorldModule;
import syrux.client.module.misc.DiscordRPCModule;
import syrux.client.module.misc.DuelHelperModule;
import syrux.client.module.player.ElytraHelperModule;
import syrux.client.module.movement.FlightModule;
import syrux.client.module.render.FreeCameraModule;
import syrux.client.module.misc.GlobalsModule;
import syrux.client.module.combat.HitBoxesModule;
import syrux.client.module.misc.InfoReplaceModule;
import syrux.client.module.render.InterfaceModule;
import syrux.client.module.combat.ItemHelperModule;
import syrux.client.module.player.ItemScrollerModule;
import syrux.client.module.render.JumpCircleModule;
import syrux.client.module.combat.MaceHelperModule;
import syrux.client.module.render.MotionBlurModule;
import syrux.client.module.misc.NameProtectModule;
import syrux.client.module.combat.NoEntityTraceModule;
import syrux.client.module.player.NoPlayerDelayModule;
import syrux.client.module.player.NoPushModule;
import syrux.client.module.render.NoRenderModule;
import syrux.client.module.combat.NoServerPackModule;
import syrux.client.module.movement.NoSlowModule;
import syrux.client.module.render.ParticlesModule;
import syrux.client.module.misc.PartyModule;
import syrux.client.module.misc.PotionCombinerModule;
import syrux.client.module.player.PotionThrowerModule;
import ru.dreamix.protection.api.impl.profile.ProfileAPI;
import syrux.client.module.render.ProjectilePredictionModule;
import ru.dreamix.protection.api.impl.profile.objects.RoleObject;
import syrux.client.module.movement.ScreenWalkModule;
import syrux.client.module.render.SeeInvisibleModule;
import syrux.client.module.player.ServerHelperModule;
import syrux.client.module.render.ShulkerPreviewModule;
import syrux.client.module.render.SkeletonEspModule;
import syrux.client.module.render.SmoothFeatureModule;
import syrux.client.module.movement.SpiderModule;
import syrux.client.module.misc.StreamerModModule;
import syrux.client.module.render.StructureInfoModule;
import syrux.client.module.render.SwordAnimationsModule;
import syrux.client.module.render.TagsModule;
import syrux.client.module.render.TargetEspModule;
import syrux.client.module.render.TorusModule;
import syrux.client.module.render.TotemGhostModule;
import syrux.client.module.combat.TriggerBotModule;
import syrux.client.module.player.UseTrackerModule;
import syrux.client.module.combat.VelocityModule;
import syrux.client.module.render.ViewModelModule;
import syrux.client.module.render.WardenEspModule;
import syrux.client.module.misc.YTMODEModule;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
   private static final List<Module> modules = new ArrayList<>();
   private static boolean initialized;

   public static Module findByName(String local866_0) {
      for (Module module : modules) {
         if (module.name.equalsIgnoreCase(local866_0)) {
            return module;
         }
      }

      return null;
   }

   public static void registerModule(Module module) {
      if (module != null && !modules.contains(module)) {
         if (!(module instanceof AutoMineModule)
               && !(module instanceof AutoBuyModule)
               && !(module instanceof AutoVillagerModule)
               && !(module instanceof AutoAppleFarmModule)
               && !(module instanceof AutoWardenModule)
            || ProfileAPI.get().getModel().getRole().priorityHigherOrEquals(RoleObject.BETA)) {
            if (!(module instanceof YTMODEModule) || ProfileAPI.get().getModel().getRole().priorityHigherOrEquals(RoleObject.YOUTUBE)) {
               if (!(module instanceof AdminShardModule) || ProfileAPI.get().getModel().getRole().priorityHigherOrEquals(RoleObject.ADMIN)) {
                  if (!(module instanceof AdminRecordModule) || ProfileAPI.get().getModel().getRole().priorityHigherOrEquals(RoleObject.ADMIN)) {
                     modules.add(module);
                  }
               }
            }
         }
      }
   }

   public static List<Module> getModules() {
      return modules;
   }

   private ModuleManager() {
   }

   public static void unregisterModule(Module module) {
      modules.remove(module);
   }

   public static List<Module> getModulesByCategory(ModuleCategory moduleCategory) {
      List<Module> local871_1 = new ArrayList<>();

      for (Module module : modules) {
         if (module.category == moduleCategory) {
            local871_1.add(module);
         }
      }

      return local871_1;
   }

   public static void initializeModules() {
      if (!initialized) {
         initialized = true;
         registerModule(AttackAuraModule.method1029());
         registerModule(MaceHelperModule.method1776());
         registerModule(AutoSwapModule.method2577());
         registerModule(AutoTotemModule.method3667());
         registerModule(TriggerBotModule.method4593());
         registerModule(ItemHelperModule.method3711());
         registerModule(AimAssistModule.method0883());
         registerModule(NoEntityTraceModule.method3535());
         registerModule(NoServerPackModule.method1257());
         registerModule(HitBoxesModule.method1050());
         registerModule(BackTrackModule.method2909());
         registerModule(AutoRegisterModule.method2677());
         registerModule(AuctionHelperModule.method2310());
         registerModule(AutoLeaveModule.method4407());
         registerModule(AutoToolModule.method3003());
         registerModule(AutoEatModule.method3868());
         registerModule(AutoAcceptModule.method3705());
         registerModule(AutoDeliverModule.method3798());
         registerModule(ClanUpgraderModule.method1377());
         if (ProfileAPI.get().getModel().getRole().priorityHigherOrEquals(RoleObject.BETA)) {
            registerModule(AutoMineModule.method3460());
            registerModule(AutoBuyModule.method1734());
            registerModule(AutoVillagerModule.method2125());
            registerModule(AutoAppleFarmModule.method1189());
            registerModule(AutoWardenModule.method1584());
         }

         registerModule(AutoSellModule.method1417());
         registerModule(BotManagerModule.method4821());
         registerModule(PotionCombinerModule.method0722());
         registerModule(ChestStealerModule.method0936());
         registerModule(InfoReplaceModule.method3429());
         registerModule(StreamerModModule.method0449());
         registerModule(YTMODEModule.method1426());
         registerModule(NameProtectModule.method2868());
         registerModule(GlobalsModule.method0643());
         registerModule(syrux.client.module.render.WindPredictModule.getInstance());
         registerModule(syrux.client.module.render.FriendPingsModule.getInstance());
         registerModule(DiscordRPCModule.method3302());
         registerModule(DuelHelperModule.method1172());
         registerModule(AutoMessageModule.method2253());
         registerModule(BaseFinderModule.getInstance());
         registerModule(AirStuckModule.method2785());
         registerModule(AutoSprintModule.method3360());
         registerModule(FlightModule.method2902());
         registerModule(ScreenWalkModule.method0991());
         registerModule(VelocityModule.method1538());
         registerModule(NoSlowModule.method4030());
         registerModule(SpiderModule.method2836());
         registerModule(ItemScrollerModule.method3994());
         registerModule(NoPushModule.method3305());
         registerModule(BlockSlotModule.method1380());
         registerModule(NoRenderModule.method3426());
         ProjectilePredictionModule.method1623();
         registerModule(TagsModule.method4106());
         registerModule(TargetEspModule.method1936());
         registerModule(ArmorBarModule.method4127());
         registerModule(ShulkerPreviewModule.method2995());
         registerModule(SkeletonEspModule.method2471());
         registerModule(ChamsModule.method2783());
         registerModule(BlockEspModule.method3044());
         registerModule(SeeInvisibleModule.method4439());
         registerModule(TorusModule.method4172());
         TotemGhostModule.method2610();
         registerModule(CrosshairModule.method3070());
         registerModule(ArrowsModule.method3119());
         registerModule(BassBoostModule.method4264());
         registerModule(ClickActionModule.method0841());
         registerModule(AutoExpModule.method4034());
         registerModule(ElytraHelperModule.method0984());
         registerModule(NoPlayerDelayModule.method0475());
         registerModule(FreeCameraModule.method0910());
         registerModule(CameraFeatureModule.method0782());
         registerModule(SwordAnimationsModule.method1770());
         registerModule(ViewModelModule.method3027());
         registerModule(InterfaceModule.method2247());
         SmoothFeatureModule.method3278();
         registerModule(AspectRatioModule.method1041());
         registerModule(StructureInfoModule.method3231());
         registerModule(WardenEspModule.method1959());
         registerModule(JumpCircleModule.method0833());
         registerModule(BlockOverlayModule.method3643());
         registerModule(ParticlesModule.method0596());
         registerModule(MotionBlurModule.method3837());
         registerModule(CustomWorldModule.method2204());
         registerModule(BrightnessModule.method0820());
         registerModule(ServerHelperModule.method0707());
         registerModule(PotionThrowerModule.method2641());
         registerModule(UseTrackerModule.method1800());
      }
   }
}

