package syrux.client.module.render;

import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import syrux.client.event.EventListener;
import syrux.client.event.WorldRenderEvent;
import syrux.client.module.Module;
import syrux.client.module.ModuleCategory;
import syrux.client.module.ModuleInfo;
import syrux.client.setting.BooleanSetting;

import java.util.ArrayList;
import java.util.List;

/** Animated projected wind-charge landing position (approximate, not server-authoritative). */
@ModuleInfo(name = "Wind Predict", category = ModuleCategory.RENDER,
    description = "Анимированная траектория и точка приземления после заряда ветра")
public final class WindPredictModule extends Module {
    private static WindPredictModule instance;
    private final BooleanSetting path = addSetting(new BooleanSetting("Траектория", "Линия предполагаемого полёта", true));
    private final BooleanSetting circle = addSetting(new BooleanSetting("Круг приземления", "Пульсирующий маркер на земле", true));
    private final BooleanSetting animated = addSetting(new BooleanSetting("Анимация", "Вращение и пульсация колец", true));
    private final BooleanSetting onlyWind = addSetting(new BooleanSetting("Только заряд ветра", "Показывать после применения заряда ветра", true));
    private Vec3d smoothLanding;
    private long lastHeldChargeMs;

    public static WindPredictModule getInstance() {
        if (instance == null) instance = new WindPredictModule();
        return instance;
    }

    private WindPredictModule() { super(); }

    private final EventListener<WorldRenderEvent> render = event -> {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        final long millis = System.currentTimeMillis();
        final boolean holding = ((net.minecraft.entity.LivingEntity) mc.player).getMainHandStack().isOf(Items.WIND_CHARGE)
            || ((net.minecraft.entity.LivingEntity) mc.player).getOffHandStack().isOf(Items.WIND_CHARGE);
        if (holding) lastHeldChargeMs = millis;
        if (onlyWind.isChecked() && millis - lastHeldChargeMs > 1800L) {
            smoothLanding = null;
            return;
        }
        // The actual wind-charge impulse is already reflected in the player's velocity.
        // Rendering begins after launch instead of pretending to know the un-fired boost.
        if (((net.minecraft.entity.Entity) mc.player).isOnGround() || ((net.minecraft.entity.Entity) mc.player).isTouchingWater() || ((net.minecraft.entity.LivingEntity) mc.player).isClimbing()) {
            smoothLanding = null;
            return;
        }
        Vec3d start = ((net.minecraft.entity.Entity) mc.player).getEntityPos();
        Vec3d velocity = ((net.minecraft.entity.Entity) mc.player).getVelocity();
        if (velocity.lengthSquared() < 0.0001) return;

        List<Vec3d> points = new ArrayList<>(90);
        points.add(start.add(0.0, 0.08, 0.0));
        Vec3d pos = start;
        Vec3d landing = null;
        Box originalBox = ((net.minecraft.entity.Entity) mc.player).getBoundingBox();
        for (int tick = 0; tick < 90; tick++) {
            Vec3d next = pos.add(velocity);
            Box nextBox = originalBox.offset(next.subtract(start));
            if (!((net.minecraft.world.CollisionView) mc.world).isSpaceEmpty(mc.player, nextBox)) {
                // Find first approximate contact with the collision volume.
                Vec3d low = pos, high = next;
                for (int i = 0; i < 7; i++) {
                    Vec3d mid = low.lerp(high, 0.5);
                    if (((net.minecraft.world.CollisionView) mc.world).isSpaceEmpty(mc.player, originalBox.offset(mid.subtract(start)))) low = mid;
                    else high = mid;
                }
                landing = low;
                points.add(low.add(0.0, 0.08, 0.0));
                break;
            }
            points.add(next.add(0.0, 0.08, 0.0));
            pos = next;
            if (pos.y < ((net.minecraft.world.HeightLimitView) mc.world).getBottomY()) break;
            // Air movement approximation; steering, levitation and server physics can differ.
            velocity = new Vec3d(velocity.x * 0.91, (velocity.y - 0.08) * 0.98, velocity.z * 0.91);
        }
        Vec3d cam = ((net.minecraft.world.waypoint.TrackedWaypoint.YawProvider) mc.gameRenderer.getCamera()).getCameraPos();
        MatrixStack matrices = event.method0647();
        VertexConsumer pen = ((net.minecraft.client.render.VertexConsumerProvider) mc.getBufferBuilders().getEntityVertexConsumers()).getBuffer(RenderLayers.lines());
        double seconds = millis / 1000.0;
        if (path.isChecked()) {
            for (int i = 1; i < points.size(); i++) {
                Vec3d a = points.get(i-1), b = points.get(i);
                float alpha = 0.90f - 0.44f * ((float)i / points.size());
                drawSegment(pen, matrices, a.subtract(cam), b.subtract(cam), 0x00FFD54A | ((int)(alpha*255)<<24), 2.3f);
            }
        }
        if (landing != null && circle.isChecked()) {
            smoothLanding = smoothLanding == null || smoothLanding.squaredDistanceTo(landing) > 25
                ? landing : smoothLanding.lerp(landing, 0.27);
            double t = animated.isChecked() ? seconds : 0.0;
            double pulse = animated.isChecked() ? 1.0 + 0.09 * Math.sin(t*5.0) : 1.0;
            drawRing(pen, matrices, smoothLanding.subtract(cam).add(0,0.035,0),0.75*pulse,
                0xECFFFFFF, 2.4f, 0);
            drawRing(pen, matrices, smoothLanding.subtract(cam).add(0,0.05,0), 0.92*pulse,
                0xAFFFCA24, 2.0f, t * 1.6);
            if (animated.isChecked()) drawOrbitAccents(pen, matrices,
                smoothLanding.subtract(cam).add(0,0.07,0), 0.98*pulse, t*1.8);
            drawRing(pen, matrices, smoothLanding.subtract(cam).add(0,0.06,0),0.34,
                0x9AFFCA24, 1.5f, -t);
        } else if (landing == null) {
            smoothLanding = null;
        }
        mc.getBufferBuilders().getEntityVertexConsumers().draw();
    };

    private static void drawOrbitAccents(VertexConsumer out, MatrixStack matrices, Vec3d origin,
                                         double radius, double time) {
        for (int arc = 0; arc < 4; arc++) {
            for (int segment = 0; segment < 7; segment++) {
                double a = time + arc * Math.PI / 2 + segment * Math.PI / 90;
                double b = time + arc * Math.PI / 2 + (segment + 1) * Math.PI / 90;
                Vec3d p = origin.add(Math.cos(a)*radius,0,Math.sin(a)*radius);
                Vec3d q = origin.add(Math.cos(b)*radius,0,Math.sin(b)*radius);
                drawSegment(out, matrices, p, q, 0xFFFFE79C, 3.5f);
            }
        }
    }

    private static void drawRing(VertexConsumer out, MatrixStack matrices, Vec3d origin,
                                 double radius, int color, float width, double rotation) {
        final int segments = 64;
        for (int i=0;i<segments;i++) {
            double a=rotation+i*Math.PI*2/segments, b=rotation+(i+1)*Math.PI*2/segments;
            Vec3d p=origin.add(Math.cos(a)*radius,0,Math.sin(a)*radius);
            Vec3d q=origin.add(Math.cos(b)*radius,0,Math.sin(b)*radius);
            drawSegment(out,matrices,p,q,color,width);
        }
    }

    private static void drawSegment(VertexConsumer out, MatrixStack matrices, Vec3d a, Vec3d b,
                                    int color, float width) {
        Vec3d d=b.subtract(a);
        if (d.lengthSquared() < 1.0E-9) return;
        Vec3d normal=d.normalize();
        out.vertex(matrices.peek(), (float)a.x, (float)a.y,(float)a.z).color(color)
            .normal(matrices.peek(),(float)normal.x,(float)normal.y,(float)normal.z).lineWidth(width);
        out.vertex(matrices.peek(), (float)b.x, (float)b.y,(float)b.z).color(color)
            .normal(matrices.peek(),(float)normal.x,(float)normal.y,(float)normal.z).lineWidth(width);
    }

    @Override protected void onDisable() { smoothLanding=null; lastHeldChargeMs=0L; }
}
