package syrux.client;

import syrux.client.storage.AccountStore;
import syrux.client.command.AutowardenCommand;
import syrux.client.command.BaseCommand;
import syrux.client.command.BlockespCommand;
import syrux.client.ui.ClickGuiScreen;
import syrux.client.command.ClientCommand;
import syrux.client.event.ClientTickEvent;
import syrux.client.command.CommandDispatcher;
import syrux.client.command.ConfigCommand;
import syrux.client.cosmetic.CosmeticFeatureRenderer;
import syrux.client.cosmetic.CosmeticsApi;
import syrux.client.cosmetic.CosmeticCategory;
import syrux.client.cosmetic.CosmeticEntry;
import syrux.client.cosmetic.CosmeticCatalog;
import syrux.client.cosmetic.CosmeticStore;
import syrux.client.module.misc.GlobalsModule;
import syrux.client.ui.MainMenuScreen;
import syrux.client.event.Event;
import syrux.client.event.EventBus;
import syrux.client.command.CosmeticCommand;
import syrux.client.command.CosmeticSyncCommand;
import syrux.client.command.FriendCommand;
import syrux.client.command.HelpCommand;
import syrux.client.ui.hud.HudLayout;
import syrux.client.command.IrcCommand;
import syrux.client.command.MacroCommand;
import syrux.client.storage.MacroStore;
import syrux.client.module.ModuleManager;
import syrux.client.command.PartyCommand;
import ru.dreamix.protection.api.impl.profile.ProfileAPI;
import syrux.client.command.RctCommand;
import syrux.client.command.WaypointCommand;
import syrux.client.util.FrameTimer;
import syrux.client.util.WaypointManager;
import syrux.client.command.ResourcePackCommand;
import syrux.client.ui.UiWarmup;
import syrux.client.render.ThemePaletteBuffer;
import syrux.client.render.ItemRenderCache;
import syrux.client.render.PipelineWarmup;
import syrux.client.storage.ConfigStore;
import syrux.client.util.IrcClient;
import syrux.client.cosmetic.CosmeticRenderDispatcher;
import syrux.client.cosmetic.CosmeticSync;
import syrux.client.cosmetic.CosmeticWarmup;
import syrux.client.render.Render2D;
import ru.dreamix.protection.api.impl.profile.objects.RoleObject;
import syrux.client.command.StaffCommand;

import java.util.ArrayList;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.ClientStarted;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.ClientStopping;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.StartTick;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.KeyBinding.Category;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.resource.ResourceType;
import net.minecraft.resource.SynchronousResourceReloader;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SyruxClient implements ModInitializer, ClientModInitializer {
   public static final String TEXT_SYRUX = "syrux";
   private static final SyruxClient deluxeClient = new SyruxClient();
   private static final Logger LOGGER = LoggerFactory.getLogger("syrux");
   private long loadTimeMillis;
   private boolean loaded;
   private int autosaveTicks;
   private CommandDispatcher commandDispatcher;
   private KeyBinding openGuiKey;
   private final FrameTimer frameTimer = new FrameTimer();

   public boolean loaded() {
      return this.loaded;
   }

   public static Identifier id(String local6600_0) {
      return Identifier.of("syrux", local6600_0);
   }

   public KeyBinding openGuiKey() {
      return this.openGuiKey;
   }

   private void registerOpenKey() {
      this.openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.syrux.clickgui", Type.KEYSYM, 344, Category.GAMEPLAY));
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)minecraftClient -> {
         while (this.openGuiKey.wasPressed()) {
            if (minecraftClient.currentScreen == null) {
               minecraftClient.setScreen(ClickGuiScreen.instance());
            }
         }
      });
      if (Boolean.getBoolean("syrux.openGui") || System.getenv("SYRUX_OPEN_GUI") != null) {
         ClientTickEvents.END_CLIENT_TICK.register((EndTick)minecraftClient2 -> {
            if (minecraftClient2.currentScreen instanceof MainMenuScreen) {
               minecraftClient2.setScreen(ClickGuiScreen.instance());
            }
         });
      }
   }

   public CommandDispatcher commandDispatcher() {
      return this.commandDispatcher;
   }

   private void registerTicks() {
      ClientTickEvents.START_CLIENT_TICK.register((StartTick)minecraftClient -> {
         if (EventBus.getInstance().hasListeners(ClientTickEvent.class)) {
            EventBus.getInstance().post(new ClientTickEvent(Event.Stage.PRE));
         }
      });
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)minecraftClient2 -> {
         if (EventBus.getInstance().hasListeners(ClientTickEvent.class)) {
            EventBus.getInstance().post(new ClientTickEvent(Event.Stage.POST));
         }

         // Cloud features are opt-in through Syrex in-game login.
         syrux.client.auth.SyrexAuthService.checkWhenDue(minecraftClient2.runDirectory.toPath());
         syrux.client.auth.SyrexGamePresence.tick(minecraftClient2);
         CosmeticsApi.getInstance().tick(minecraftClient2);
         if (minecraftClient2.currentScreen instanceof MainMenuScreen
               && !syrux.client.auth.SyrexAuthService.authenticated()) {
            minecraftClient2.setScreen(new syrux.client.auth.SyrexLoginScreen());
         }

         if (this.loaded && ++this.autosaveTicks >= 1200) {
            this.autosaveTicks = 0;
            ConfigStore.autosave();
         }
      });
   }

   public static Logger logger() {
      return LOGGER;
   }

   @Override
   public String toString() {
      return "Syrux(loadTimeMs="
         + this.loadTimeMs()
         + ", loaded="
         + this.loaded()
         + ", autosaveTicks="
         + this.autosaveTicks()
         + ", commandDispatcher="
         + this.commandDispatcher()
         + ", openGuiKey="
         + this.openGuiKey()
         + ", framelibrary="
         + this.framelibrary()
         + ")";
   }

   public int autosaveTicks() {
      return this.autosaveTicks;
   }

   private void registerCosmetics() {
      CosmeticWarmup.method2917();
      CosmeticWarmup.method2911();
      LivingEntityFeatureRendererRegistrationCallback.EVENT
         .register((LivingEntityFeatureRendererRegistrationCallback)(local6603_0, local6603_1, registrationHelper, context) -> {
            if (local6603_1 instanceof PlayerEntityRenderer<?> local6603_4) {
               registrationHelper.register(new CosmeticFeatureRenderer(local6603_4));
            }
         });
      CosmeticRenderDispatcher.method2887();
   }

   @Override
   public boolean equals(Object local6612_1) {
      if (local6612_1 == this) {
         return true;
      } else if (!(local6612_1 instanceof SyruxClient currentDeluxeClient)) {
         return false;
      } else {
         if (!currentDeluxeClient.canEqual(this)) {
            return false;
         }

         if (this.loadTimeMs() != currentDeluxeClient.loadTimeMs()) {
            return false;
         }

         if (this.loaded() != currentDeluxeClient.loaded()) {
            return false;
         }

         if (this.autosaveTicks() != currentDeluxeClient.autosaveTicks()) {
            return false;
         }

         Object local6612_3 = this.commandDispatcher();
         Object local6612_4 = currentDeluxeClient.commandDispatcher();
         if (local6612_3 == null ? local6612_4 == null : local6612_3.equals(local6612_4)) {
            Object local6612_5 = this.openGuiKey();
            Object local6612_6 = currentDeluxeClient.openGuiKey();
            if (local6612_5 == null ? local6612_6 == null : local6612_5.equals(local6612_6)) {
               Object local6612_7 = this.framelibrary();
               Object local6612_8 = currentDeluxeClient.framelibrary();
               return local6612_7 == null ? local6612_8 == null : local6612_7.equals(local6612_8);
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   public SyruxClient commandDispatcher(CommandDispatcher newCommandDispatcher) {
      this.commandDispatcher = newCommandDispatcher;
      return this;
   }

   public void unload() {
      ConfigStore.saveActiveConfig();
      ItemRenderCache.method2350();
      Render2D.method4714();
      this.loaded = false;
      LOGGER.info("shutdown");
   }

   public void load() {
      ProfileAPI.create("user", 1, RoleObject.ADMIN);
      this.loadTimeMillis = System.currentTimeMillis();
      System.setProperty("sun.font.layout.ffm", "false");
      Render2D.method4728();
      ItemRenderCache.method2335();
      ThemePaletteBuffer.method2143();
      UiWarmup.method1949();
      HudLayout.method4568();
      ModuleManager.initializeModules();
      EventBus.getInstance().subscribe(AccountStore.method4153());
      EventBus.getInstance().subscribe(WaypointManager.method0947());
      EventBus.getInstance().subscribe(MacroStore.method4213());
      EventBus.getInstance().subscribe(IrcClient.method2834());
      this.registerCosmetics();
      this.initCommands();
      this.registerOpenKey();
      this.registerTicks();

      // Initialize cosmetic synchronization
      CosmeticSync.getInstance().initialize();

      // Auto-load own cosmetics on world join
      ClientLifecycleEvents.CLIENT_STARTED.register((ClientStarted) minecraftClient -> {
         if (minecraftClient.player != null && GlobalsModule.method0643().booleanSetting.isChecked()) {
            java.util.UUID uuid = minecraftClient.player.getUuid();
            if (uuid != null) {
               CosmeticsApi.getInstance().forceRefresh(uuid).thenAccept(response -> {
                  if (response != null && response.has("cape") && response.get("cape").isJsonPrimitive()) {
                     String capeId = response.get("cape").getAsString();
                     if (capeId != null && !capeId.isEmpty()) {
                        try {
                           int cosmeticId = Integer.parseInt(capeId);
                           CosmeticEntry entry = CosmeticCatalog.method0518(cosmeticId);
                           if (entry != null && entry.category() == CosmeticCategory.CAPE) {
                              CosmeticStore.method3513(entry);
                              SyruxClient.logger().info("[Cosmetics] Auto-loaded cape: {}", entry.name());
                           }
                        } catch (NumberFormatException ignored) {
                           // cape ID might be a name, try to find by name
                           for (CosmeticEntry e : CosmeticCatalog.method0523(CosmeticCategory.CAPE)) {
                              if (e.name().equalsIgnoreCase(capeId)) {
                                 CosmeticStore.method3513(e);
                                 SyruxClient.logger().info("[Cosmetics] Auto-loaded cape: {}", e.name());
                                 break;
                              }
                           }
                        }
                     }
                  }
               }).exceptionally(throwable -> {
                  SyruxClient.logger().warn("[Cosmetics] Failed to auto-load cape: {}", throwable.getMessage());
                  return null;
               });
            }
         }
      });

      ConfigStore.loadLastConfig();
      ClientLifecycleEvents.CLIENT_STOPPING.register((ClientStopping)minecraftClient -> this.unload());
      Runtime.getRuntime().addShutdownHook(new Thread(() -> {
         if (this.loaded) {
            ConfigStore.saveActiveConfig();
         }
      }));
      ResourceLoader.get(ResourceType.CLIENT_RESOURCES).registerReloader(id("render_warmup"), (SynchronousResourceReloader)resourceManager -> {
         MinecraftClient minecraftClient2 = MinecraftClient.getInstance();
         if (minecraftClient2 != null) {
            minecraftClient2.execute(() -> {
               Render2D.method4652();
               PipelineWarmup.resetWarmup();
               UiWarmup.method1947();
            });
         }
      });
      this.loaded = true;
   }

   public SyruxClient loaded(boolean newLoaded) {
      this.loaded = newLoaded;
      return this;
   }

   public SyruxClient loadTimeMs(long newLoadTimeMillis) {
      this.loadTimeMillis = newLoadTimeMillis;
      return this;
   }

   public SyruxClient autosaveTicks(int newAutosaveTicks) {
      this.autosaveTicks = newAutosaveTicks;
      return this;
   }

   public void onInitializeClient() {
      deluxeClient.load();
   }

   public FrameTimer framelibrary() {
      return this.frameTimer;
   }

   public SyruxClient openGuiKey(KeyBinding keyBinding) {
      this.openGuiKey = keyBinding;
      return this;
   }

   @Override
   public int hashCode() {
      int local6627_1 = 59;
      int local6627_2 = 1;
      long local6627_3 = this.loadTimeMs();
      local6627_2 = local6627_2 * 59 + (int)(local6627_3 >>> 32 ^ local6627_3);
      local6627_2 = local6627_2 * 59 + (this.loaded() ? 79 : 97);
      local6627_2 = local6627_2 * 59 + this.autosaveTicks();
      Object local6627_5 = this.commandDispatcher();
      local6627_2 = local6627_2 * 59 + (local6627_5 == null ? 43 : local6627_5.hashCode());
      Object local6627_6 = this.openGuiKey();
      local6627_2 = local6627_2 * 59 + (local6627_6 == null ? 43 : local6627_6.hashCode());
      Object local6627_7 = this.framelibrary();
      return local6627_2 * 59 + (local6627_7 == null ? 43 : local6627_7.hashCode());
   }

   public static SyruxClient inst() {
      return deluxeClient;
   }

   private void initCommands() {
      ArrayList<ClientCommand> local6629_1 = new ArrayList<>();
      local6629_1.add(new ResourcePackCommand());
      local6629_1.add(new ConfigCommand());
      local6629_1.add(new FriendCommand());
      local6629_1.add(new WaypointCommand());
      local6629_1.add(new MacroCommand());
      local6629_1.add(new StaffCommand());
      local6629_1.add(new BlockespCommand());
      local6629_1.add(new AutowardenCommand());
      local6629_1.add(new RctCommand());
      local6629_1.add(new IrcCommand());
      local6629_1.add(new PartyCommand());
      local6629_1.add(new CosmeticSyncCommand());
      local6629_1.add(new CosmeticCommand());
      local6629_1.add(new BaseCommand());
      local6629_1.add(new HelpCommand(local6629_1));
      this.commandDispatcher = new CommandDispatcher(local6629_1, ".");
   }

   public void onInitialize() {
      LOGGER.info("Syrex initialized");
   }

   public long loadTimeMs() {
      return this.loadTimeMillis;
   }

   protected boolean canEqual(Object local6635_1) {
      return local6635_1 instanceof SyruxClient;
   }
}

