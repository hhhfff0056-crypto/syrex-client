package syrux.client.command;

import syrux.client.SyruxClient;
import syrux.client.cosmetic.CosmeticSync;
import syrux.client.util.ClientChat;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class CosmeticSyncCommand implements ClientCommand {
    public CosmeticSyncCommand() {
    }

    @Override
    public void execute(String[] args) {
        CosmeticSync sync = CosmeticSync.getInstance();
        
        if (args.length == 0) {
            showHelp();
            return;
        }

        String subCommand = args[0].toLowerCase();

        switch (subCommand) {
            case "sync", "force" -> {
                ClientChat.method2261(Text.literal("§a[CosmeticSync] §rForcing sync with server..."));
                sync.forceSync().thenAccept(v -> {
                    if (sync.isSynced()) {
                        ClientChat.method2261(Text.literal("§a[CosmeticSync] §rSync completed! Owned cosmetics: " + sync.getOwnedCosmeticIds().size()));
                    } else {
                        ClientChat.method2261(Text.literal("§c[CosmeticSync] §rВойди в Syrex для синхронизации"));
                    }
                });
            }
            case "status" -> {
                ClientChat.method2261(Text.literal("§e[CosmeticSync] §rStatus:"));
                ClientChat.method2261(Text.literal("  §7Synced: §r" + (sync.isSynced() ? "§aYes" : "§cNo")));
                ClientChat.method2261(Text.literal("  §7Owned cosmetics: §r" + sync.getOwnedCosmeticIds().size()));
                ClientChat.method2261(Text.literal("  §7Equipped: §r" + getEquippedSummary(sync)));
            }
            case "owned" -> {
                var owned = sync.getOwnedCosmeticIds();
                if (owned.isEmpty()) {
                    ClientChat.method2261(Text.literal("§7[CosmeticSync] No owned cosmetics synced"));
                } else {
                    ClientChat.method2261(Text.literal("§e[CosmeticSync] §rOwned cosmetics (" + owned.size() + "):"));
                    for (int id : owned) {
                        ClientChat.method2261(Text.literal("  §7- §rID: " + id));
                    }
                }
            }
            default -> showHelp();
        }
    }

    private String getEquippedSummary(CosmeticSync sync) {
        StringBuilder sb = new StringBuilder();
        for (syrux.client.cosmetic.CosmeticCategory cat : syrux.client.cosmetic.CosmeticCategory.values()) {
            var entry = sync.getEquipped(cat);
            if (entry != null) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(cat.name().toLowerCase()).append(": ").append(entry.name());
            }
        }
        return sb.length() > 0 ? sb.toString() : "none";
    }

    private void showHelp() {
        ClientChat.method2261(Text.literal("§e[CosmeticSync] §rCommands:"));
        ClientChat.method2261(Text.literal("  §7.cosmeticsync sync §r- Force sync with server"));
        ClientChat.method2261(Text.literal("  §7.cosmeticsync status §r- Show sync status"));
        ClientChat.method2261(Text.literal("  §7.cosmeticsync owned §r- List owned cosmetics"));
    }

    @Override
    public String getName() {
        return "cosmeticsync";
    }

    @Override
    public String getDescription() {
        return "Syrex website cosmetic sync (.cosmeticsync sync, .cosmeticsync status)";
    }
}