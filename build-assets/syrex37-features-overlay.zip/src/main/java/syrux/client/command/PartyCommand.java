package syrux.client.command;

import java.util.ArrayList;
import java.util.Arrays;
import syrux.client.module.render.FriendPingsModule;

/** Client-only Syrex party commands. The existing chat command manager calls execute(). */
public final class PartyCommand implements ClientCommand {
    @Override public String getName() { return "party"; }
    @Override public String getDescription() {
        return "Пати Syrex: .party <ник>, accept, decline, list, leave, kick <ник>";
    }
    @Override public ArrayList<String> suggestArguments(String[] args) {
        return new ArrayList<>(Arrays.asList("accept", "decline", "list", "info", "leave", "kick"));
    }
    @Override public void execute(String[] args) {
        FriendPingsModule.getInstance().runPartyArgs(args);
    }
}
